---
title: "My First CTF Writeup"
date: "2025-06-25"
---

# My First CTF Writeup

This is my first CTF writeup!  
Here's how I solved challenge X...

\`\`\`python
print("Hello from the writeup!")
\`\`\`
